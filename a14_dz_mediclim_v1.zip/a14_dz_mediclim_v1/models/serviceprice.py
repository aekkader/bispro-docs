from odoo import api, fields, models

class ServicePrice(models.Model):
    _inherit = "product.template"

    main_oeuvre = fields.Float(string="Main d'Oeuvre")
    frais_divers = fields.Float(string="Frais Divers")
    marge = fields.Integer(string="Marge%")
    # marge = fields.Integer(string="Marge (%)")

    # list_price = fields.Float(string="Prix de vente")
    list_price_v2 = fields.Float(string="Prix de vente V2", compute='_lst_price')


    # self.list_price = fields.Float(string="Prix de vente", compute='_lst_price_v3')

    product_id = fields.Many2one('product.template', string='Produit')
    produit_associe = fields.One2many('product.template', 'product_id', string="Les produits associes")

    # description_prod = fields.Char(string='Description Prod')

    # @api.depends('qty_contractuel', 'pu')
    # @api.one
    def _lst_price(self):
        # self.mnt_contractuel = self.qty_contractuel * self.task_id.pu
        sumProd=0
        sumProdPercent = 0
        for oneProd in self.produit_associe:
            sumProd += oneProd.list_price

        for r in self:
            sumProdPercent = sumProd * r.marge/100
            r.list_price_v2 = sumProd + r.main_oeuvre + r.frais_divers + sumProdPercent;


    # @api.onchange('type')
    # def onchange_type(self):
    #     for rec in self:
    #         if rec == 'service':
    #             self.list_price = fields.Float(string="Prix de vente", compute='_lst_price_v3')
    #         else:
    #             self.list_price = fields.Float(string="Prix de vente")

    # @api.onchange('type')
    # def onchange_type(self):
    #     for rec in self:
    #         if rec.type == 'service':



