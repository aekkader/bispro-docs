# from odoo import api, fields, models
from odoo import api, fields, models, _


# def __init__(self, pool, cr):
#     """ Override of __init__ to add access rights on notification_email_send
#         and alias fields. Access rights are disabled by default, but allowed
#         on some specific fields defined in self.SELF_{READ/WRITE}ABLE_FIELDS.
#     """
#     init_res = super(ResUsers, self).__init__(pool, cr)
#     # duplicate list to avoid modifying the original reference
#     type(self).SELF_WRITEABLE_FIELDS = list(self.SELF_WRITEABLE_FIELDS)
#     type(self).SELF_WRITEABLE_FIELDS.extend(['sidebar_visible'])
#     # duplicate list to avoid modifying the original reference
#     type(self).SELF_READABLE_FIELDS = list(self.SELF_READABLE_FIELDS)
#     type(self).SELF_READABLE_FIELDS.extend(['sidebar_visible'])
#     return init_res

class Project(models.Model):
    _inherit = "project.project"

    is_state = fields.Boolean(string='Étatique', default=False)
    decompte_ids = fields.One2many('situation.decompte', 'project_id', string="Décomptes")

class Engineer(models.Model):
    _inherit = "res.users"

    is_engineer = fields.Boolean(string='Ingénieur', default=False)

    # def name_get(self):
    #     result = []
    #     for decompte in self:
    #         name = "Décompte des travaux réalisé N° "+str(decompte.numero)
    #         result.append((decompte.id, name))
    #     return result

# class Engineer(models.Model):
#     # _name = 'user.engineer'
#     # _inherits = "res.users"
#     _inherit = "res.users"
#
#     is_engineer = fields.Boolean(string='Ingénieur', default=False)

    # def __init__(self, pool, cr):
    #     init_res = super(res.users, self).__init__(pool, cr)
    #     self.SELF_WRITEABLE_FIELDS = list(self.SELF_WRITEABLE_FIELDS)
    #     self.SELF_WRITEABLE_FIELDS.extend(['is_engineer'])
    #     return init_res
