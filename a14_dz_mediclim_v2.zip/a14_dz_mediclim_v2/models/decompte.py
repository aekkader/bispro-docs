# -*- coding: utf-8 -*-
from odoo import api, fields, models

class SituationDecompte(models.Model):
    _name = "situation.decompte"
    _description = "Situation Décompte"

    numero = fields.Integer(string='Numéro')
    start_date = fields.Date(default=fields.Date.today, string='Date de début')
    end_date = fields.Date(default=fields.Date.today, string='Date de fin')

    description = fields.Char(string='Description')

    project_id = fields.Many2one('project.project', string='Projet')
    task_mnt_ids = fields.One2many('situation.task.montant', 'decompte_id', string="Tâches")

    def name_get(self):
        result = []
        for decompte in self:
            name = "Décompte des travaux réalisé N° "+str(decompte.numero)
            result.append((decompte.id, name))
        return result

    @api.onchange('project_id')
    def onchange_project_id(self):
        task_mnt_ids = []
        if self.project_id:
            task_ids = self.env['situation.task'].search([('project_id', '=', self.project_id.id)])
            for task_id in task_ids:
                task_mnt_ids.append((0, 0, {'task_id': task_id.id
                    , 'qty_contractuel': task_id.qty, 'qty_precedente': 0
                    , 'qty_mois': 0, 'qty_cumul': 0
                    , 'mnt_contractuel': 0, 'mnt_precedente': 0
                    , 'mnt_mois': 0, 'mnt_total': 0
                                            }))

        self.task_mnt_ids = [(5, 0, 0)]#Clear all
        self.task_mnt_ids = task_mnt_ids

"""
    @api.onchange('project_id')
    def onchange_project_id(self):
        # if self.project_id:
        #     self.task_mnt_ids = self.env['project.project'].search(
        #         [('project_id', '=', self.project_id)])
        # print(self.task_mnt_ids)

        task_ids = []
        task_mnt_ids = []
        # value = {}
        if self.project_id:
            task_ids = self.env['situation.task'].search([('project_id', '=', self.project_id.id)])
            for task_id in task_ids:
                task_mnt_ids.append((0, 0, {'task_id': task_id.id}))
        # value.update(task_ids=task_ids)
        # return {'value': value}
        self.task_mnt_ids = [(5, 0, 0)]#Clear all
        self.task_mnt_ids = task_mnt_ids
        # print(task_ids)
        # print(self.task_mnt_ids)
        # self.update({
        #     'task_mnt_ids': [(6, 0, task_mnt_ids)]
        # })
        
    # @api.onchange('project_id')
    # def onchange_project_id(self):
    #     for rec in self:
    #         return {'domain': {'task_ids': [('project_id', '=', rec.project_id.id)]}}

            # ids = [5, 7, 8, 12]
            # self.update({
            #     'task_ids': [(6, False, ids)]
            # })

"""