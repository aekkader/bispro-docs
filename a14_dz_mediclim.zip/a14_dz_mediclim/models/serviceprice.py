from odoo import api, fields, models

class ProductServiceLine(models.Model):
    _name = "product.service.line"

    qty = fields.Integer(string="Quantité")
    prix = fields.Float(string="Prix")

    product_id3 = fields.Many2one('product.template', 'Article')

    product_id2 = fields.Many2one('product.template', 'Product')
    #product_line_id = fields.Many2one('product.template', string='Produit Line')

    main_oeuvre = fields.Float(string="Main d'Oeuvre")
    frais_divers = fields.Float(string="Frais Divers")
    marge = fields.Float(string="Marge%")
    total = fields.Float(string="Total", compute='_total_compute_v1')

    def _total_compute_v1(self):
        for r in self:
            # priceSubTotal = r.product_id3.list_price + r.main_oeuvre + r.frais_divers
            priceSubTotal = r.prix + r.main_oeuvre + r.frais_divers
            pricePercent = priceSubTotal * (r.marge/100 + 1)
            r.total = pricePercent * r.qty
            # r.total = (pricePercent * r.qty) - (r.prix * r.qty)

    @api.onchange('product_id3')
    def onchange_product_id(self):
        for r in self:
            r.prix = self.product_id3.list_price


class ProductService(models.Model):
    _inherit = "product.template"

    # main_oeuvre = fields.Float(string="Main d'Oeuvre")
    # frais_divers = fields.Float(string="Frais Divers")
    # marge = fields.Integer(string="Marge%")

    # list_price = fields.Float(string="Prix de vente", compute='_lst_price_compute', inverse='_lst_price_inverse')\
    # list_price = fields.Float(string="Prix de vente", compute='_lst_price_compute_v4'
    #                           , readonly=False, store=True)
    # list_price = fields.Float(string="Prix de vente", compute='_lst_price_compute_v1'
    #                           , store=True)
    # list_price_v2 = fields.Float(string="Prix de vente V2")

    # product_line_ids = fields.One2many('product.service.line', 'product_id2', string="Les produits associes")
    product_line_ids = fields.One2many('product.service.line', 'product_id2')

    def action_calculer(self):
        for r in self:
            sumProd=0
            for oneProd in self.product_line_ids:
                # sumProd += oneProd.total
                sumProd = (oneProd.total) - (oneProd.prix * oneProd.qty)
            r.list_price = sumProd
            # r.list_price = 0

    # # @api.depends('main_oeuvre')
    # def _lst_price_compute_v2(self):
    #     for r in self:
    #         # if r.type == 'service':
    #         r.list_price = r.main_oeuvre
    #         # else :
    #         #     r.list_price = r.list_price

    # def _lst_price_inverse(self):
    #     for r in self:
    #         r.list_price = 222

    # def _lst_price(self):
    #     # self.mnt_contractuel = self.qty_contractuel * self.task_id.pu
    #     sumProd=0
    #     sumProdPercent = 0
    #     for oneProd in self.product_line_ids:
    #         sumProd += oneProd.product_line_id.list_price
    #
    #     for r in self:
    #         sumProdPercent = sumProd * r.marge/100
    #         r.list_price_v2 = sumProd + r.main_oeuvre + r.frais_divers + sumProdPercent;

