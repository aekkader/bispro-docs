from odoo import api, fields, models, _

# from odoo import api, fields, models, SUPERUSER_ID, _
from odoo.tools.misc import formatLang, get_lang


class SaleOrder(models.Model):
    _inherit = "sale.order"


    def create_order_line_v2(self, product_id):
        print("create_order_line_v2")
        for line_ord in product_id.product_line_ids:
            find_product = self.env['product.product'].search([('product_tmpl_id', '=', line_ord.product_id3.id)])
            vals = {
                'product_id': find_product.id,
                'order_id': self.id,
                'name': find_product.name
                # 'product_uom_qty': data['qte'] or 1,
                # 'price_unit': data['list_price'] or product_id.lst_price,
            }
            line = self.new(vals)
            line.product_id_change()


    def create_order_line_(self, product_id):
        print("create_order_line_")
        if not product_id:
            return

        # line_env = self.env['sale.order.line']
        # order_lines = self.order_id.order_line
        # find_order = self.env['sale.order'].search([('id', '=', self.id)])

        # print("displayOrderLines : V1")
        # self.displayOrderLines()

        pages = []
        for line_ord in product_id.product_line_ids:
            find_product = self.env['product.product'].search([('product_tmpl_id', '=', line_ord.product_id3.id)])
            # line = line_env.update({
            #     'product_id': find_product.id,
            #     'order_id': self.order_id,
            #     # 'name': 'AEK'
            #     # 'product_uom_qty': data['qte'] or 1,
            #     # 'price_unit': data['list_price'] or product_id.lst_price,
            # })
            print("line")
            print(find_product.name)
            vals = {
                'product_id': find_product.id,
                'order_id': self.id,
                'name': 'AEK'
                # 'product_uom_qty': data['qte'] or 1,
                # 'price_unit': data['list_price'] or product_id.lst_price,
            }
            # line = self.new(vals)
            # print("line")
            # print(line.product_id)
            # line.product_id_change()  # Calling an onchange method to update the record
            # # self.update(vals)
            # line.create(vals)
            pages.append((0, 0, vals))

            # self.order_line.append((0, 0, vals))
        self.update({"order_line": pages})

        # self.order_line.update({"order_line": pages})
        print("displayOrderLines : V2")
        self.displayOrderLines()


    def displayOrderLines(self):
        for line in self.order_line:
            print(line.product_id.name)
            line.product_id_change()  # Calling an onchange method to update the record


class SaleOrder(models.Model):
    _inherit = "sale.order.line"


    # @api.onchange('product_id')
    # def product_id_change(self):
    #     if not self.product_id:
    #         return
    #     valid_values = self.product_id.product_tmpl_id.valid_product_template_attribute_line_ids.product_template_value_ids
    #     # remove the is_custom values that don't belong to this template
    #     for pacv in self.product_custom_attribute_value_ids:
    #         if pacv.custom_product_template_attribute_value_id not in valid_values:
    #             self.product_custom_attribute_value_ids -= pacv
    #
    #     # remove the no_variant attributes that don't belong to this template
    #     for ptav in self.product_no_variant_attribute_value_ids:
    #         if ptav._origin not in valid_values:
    #             self.product_no_variant_attribute_value_ids -= ptav
    #
    #     vals = {}
    #     if not self.product_uom or (self.product_id.uom_id.id != self.product_uom.id):
    #         vals['product_uom'] = self.product_id.uom_id
    #         vals['product_uom_qty'] = self.product_uom_qty or 1.0
    #
    #     product = self.product_id.with_context(
    #         lang=get_lang(self.env, self.order_id.partner_id.lang).code,
    #         partner=self.order_id.partner_id,
    #         quantity=vals.get('product_uom_qty') or self.product_uom_qty,
    #         date=self.order_id.date_order,
    #         pricelist=self.order_id.pricelist_id.id,
    #         uom=self.product_uom.id
    #     )
    #
    #     vals.update(name=self.get_sale_order_line_multiline_description_sale(product))
    #
    #     self._compute_tax_id()
    #
    #     if self.order_id.pricelist_id and self.order_id.partner_id:
    #         vals['price_unit'] = self.env['account.tax']._fix_tax_included_price_company(
    #             self._get_display_price(product), product.taxes_id, self.tax_id, self.company_id)
    #     self.update(vals)
    #
    #     title = False
    #     message = False
    #     result = {}
    #     warning = {}
    #     if product.sale_line_warn != 'no-message':
    #         title = _("Warning for %s", product.name)
    #         message = product.sale_line_warn_msg
    #         warning['title'] = title
    #         warning['message'] = message
    #         result = {'warning': warning}
    #         if product.sale_line_warn == 'block':
    #             self.product_id = False
    #
    #     # self.order_id.create_order_line_(self.product_id)
    #     # self.order_id.displayOrderLines()
    #     # self.order_id.create_order_line_v2(self.product_id)
    #
    #     return result
    #

#     def create_order_line_(self):
#         print("create_order_line_")
#         if not self.product_id:
#             return
#
#         line_env = self.env['sale.order.line']
#         order_lines = self.order_id.order_line
#         find_order = self.env['sale.order'].search([('id', '=', self.order_id.id)])
#
#         pages = []
#         for line_ord in self.product_id.product_line_ids:
#             find_product = self.env['product.product'].search([('product_tmpl_id', '=', line_ord.product_id3.id)])
#             # line = line_env.update({
#             #     'product_id': find_product.id,
#             #     'order_id': self.order_id,
#             #     # 'name': 'AEK'
#             #     # 'product_uom_qty': data['qte'] or 1,
#             #     # 'price_unit': data['list_price'] or product_id.lst_price,
#             # })
#             vals = {
#                 'product_id': find_product.id,
#                 'order_id': self.order_id,
#                 # 'name': 'AEK'
#                 # 'product_uom_qty': data['qte'] or 1,
#                 # 'price_unit': data['list_price'] or product_id.lst_price,
#             }
#             # line = self.new(vals)
#             # print("line")
#             # print(line.product_id)
#             # line.product_id_change()  # Calling an onchange method to update the record
#             # # self.update(vals)
#             # line.create(vals)
#             pages.append((0, 0, vals))
#
#         find_order.update({"order_line": pages})
#
# #     def create_order_line_(self):
# #         print("create_order_line_")
# #         if not self.product_id:
# #             return
# #
# #         # new_line_ids = []
# #         # for line in self.product_id.product_line_ids:
# #         #     print(line.product_id3.type)
# #         #     print(line.product_id3.name)
# #         #
# #         #     new_line_ids.append((0, 0,
# #         #          {'order_id': self.order_id.id
# #         #             , 'name': line.product_id3.name
# #         #         }))
# #
# #         # self.order_id.order_line = new_line_ids
# #
# #         line_env = self.env['sale.order.line']
# #         for line_ord in self.product_id.product_line_ids:
# #             vals = {}
# #             find_product = self.env['product.product'].search([('product_tmpl_id', '=', line_ord.product_id3.id)])
# #             print("find_product")
# #             print(find_product.name)
# #
# #             vals['product_id'] = find_product.id #product.product
# #             # vals['name'] = line_ord.product_id3.name #name
# #             vals['name'] = find_product.name #name
# #             # vals['product_uom_qty'] = line_ord.qty or 1.0 #qty
# #             # vals['price_unit'] = line_ord.prix #prix u
# #             # vals['price_subtotal'] = line_ord.total
# #             # vals['tax_id'] = self.env['account.tax'].search([('id', '=', find_product.taxes_id.id)])
# #             # vals['tax_id'] = line_ord.name #account.tax
# #             # print("find_product v2")
# #             # print(find_product.name)
# #             vals['product_uom'] = find_product.uom_id.id
# #             vals['order_id'] = self.order_id
# #             # print("find_product v3")
# #             # print(find_product.name)
# #
# #             # line = self.new(vals)
# #             # line = line_env.create(vals)
# #             # line.product_id_change()  # Calling an onchange method to update the record
# #
# #             line_env.create({
# #                 'product_id': find_product.id,
# #                 'order_id': self.order_id,
# #                 # 'name': 'AEK'
# #                 # 'product_uom_qty': data['qte'] or 1,
# #                 # 'price_unit': data['list_price'] or product_id.lst_price,
# #             })
# #
# #             # self.update(vals)
# #
# # #         End for
#
#
# #     @api.onchange('product_id')
# #     def onchange_product_id(self):
# #         print("product_id v1")
# #         for r in self:
# #             # r.prix = self.product_id3.list_price
# #             # r.product_id;
# #             print("product_id")
# #             if r.product_id:
# #                 print(r.product_id)
# #
# # # add to list order_line



class PurchaseOrder(models.Model):
    _inherit = "purchase.order"

    # state = fields.Selection(selection_add([('sent2Buy', 'sent to buy')]))
    # state = fields.Selection(selection_add_after={'sent': [('sent2Buy', 'Envoyer pour achat')]})
    # state = fields.Selection(
    #     selection_add=[
    #         ('sent2Buy', 'Envoyer pour achat')
    #     ],
    # )

    state = fields.Selection([
        ('draft', 'RFQ'),
        ('sent2Buy', 'Envoyer pour achat'),
        ('sent', 'RFQ Sent'),
        ('to approve', 'To Approve'),
        ('purchase', 'Purchase Order'),
        ('done', 'Locked'),
        ('cancel', 'Cancelled')
    ], string='Status', readonly=True, index=True, copy=False, default='draft', tracking=True)

     # @ api.multi
    def action_sent2Buy(self):
        # self.state = 'sent2Buy'
        self.write({'state': 'sent2Buy'})

    def button_confirm(self):
        for order in self:
            if order.state not in ['draft', 'sent', 'sent2Buy']:
                continue
            order._add_supplier_to_product()
            # Deal with double validation process
            if order._approval_allowed():
                order.button_approve()
            else:
                order.write({'state': 'to approve'})
            if order.partner_id not in order.message_partner_ids:
                order.message_subscribe([order.partner_id.id])
        return True

    def action_rfq_send(self):
        '''
        This function opens a window to compose an email, with the edi purchase template message loaded by default
        '''
        self.ensure_one()
        ir_model_data = self.env['ir.model.data']
        try:
            if self.env.context.get('send_rfq', False):
                template_id = ir_model_data.get_object_reference('purchase', 'email_template_edi_purchase')[1]
            else:
                template_id = ir_model_data.get_object_reference('purchase', 'email_template_edi_purchase_done')[1]
        except ValueError:
            template_id = False
        try:
            compose_form_id = ir_model_data.get_object_reference('mail', 'email_compose_message_wizard_form')[1]
        except ValueError:
            compose_form_id = False
        ctx = dict(self.env.context or {})
        ctx.update({
            'default_model': 'purchase.order',
            'active_model': 'purchase.order',
            'active_id': self.ids[0],
            'default_res_id': self.ids[0],
            'default_use_template': bool(template_id),
            'default_template_id': template_id,
            'default_composition_mode': 'comment',
            'custom_layout': "mail.mail_notification_paynow",
            'force_email': True,
            'mark_rfq_as_sent': True,
        })

        # In the case of a RFQ or a PO, we want the "View..." button in line with the state of the
        # object. Therefore, we pass the model description in the context, in the language in which
        # the template is rendered.
        lang = self.env.context.get('lang')
        if {'default_template_id', 'default_model', 'default_res_id'} <= ctx.keys():
            template = self.env['mail.template'].browse(ctx['default_template_id'])
            if template and template.lang:
                lang = template._render_lang([ctx['default_res_id']])[ctx['default_res_id']]

        self = self.with_context(lang=lang)
        if self.state in ['draft', 'sent', 'sent2Buy']:
            ctx['model_description'] = _('Request for Quotation')
        else:
            ctx['model_description'] = _('Purchase Order')

        print("H1")
        return {
            'name': _('Compose Email'),
            'type': 'ir.actions.act_window',
            'view_mode': 'form',
            'res_model': 'mail.compose.message',
            'views': [(compose_form_id, 'form')],
            'view_id': compose_form_id,
            'target': 'new',
            'context': ctx,
        }

    @api.returns('mail.message', lambda value: value.id)
    def message_post(self, **kwargs):
        if self.env.context.get('mark_rfq_as_sent'):
            self.filtered(lambda o: ((o.state == 'draft') | (o.state == 'sent2Buy'))).write({'state': 'sent'})
        return super(PurchaseOrder, self.with_context(mail_post_autofollow=True)).message_post(**kwargs)



# class Project(models.Model):
#     _inherit = "project.project"
#
#     is_state = fields.Boolean(string='Étatique', default=False)
#     # rating_active = fields.Boolean('Customer Ratings', default=True)
#     decompte_ids = fields.One2many('situation.decompte', 'project_id', string="Décomptes")
#
#     def total_project(self):
#         return 22
#
#     def show_decomptes(self):
#         tree_view = {
#             'name': 'Décomptes',
#             'view_type': 'form',
#             'view_mode': 'tree,form',
#             'view_id': False,
#             # 'view_id': self.id,
#             'res_model': 'situation.decompte',
#             'type': 'ir.actions.act_window',
#             'target': 'current',
#         }
#         return tree_view

    # # @api.multi
    # def show_decomptes(self):
        # print self._context
        # course_form = self.env.ref('college.return_form', False)
        # return {
        #     'name': 'New Course',
        #     'type': 'ir.actions.act_window',
        #     'res_model': 'situation.decompte',
        #     'view_type': 'form',
        #     'view_mode': 'tree,form',
        #     'target': 'self',
        #     'views': [(self.decompte_ids, 'tree')],
        #     # 'view_id': 'course_form.id',
        #     'flags': {'action_buttons': True},
        #     }

        # context = self._context.copy()
        # return {
        #     'name': 'form_name',
        #     'view_type': 'form',
        #     'view_mode': 'tree',
        #     'views': [(self.decompte_ids, 'form')],
        #     'res_model': 'model_name',
        #     'view_id': self.decompte_ids,
        #     'type': 'ir.actions.act_window',
        #     'res_id': self.id,
        #     'target': 'new',
        #     'context': context,
        # }
        # domain = [('id', 'in', self.decompte_ids)]
        # domain = [(self.id, '=', 'project_id')]
        # tree_view = {
        #     'name': 'Décomptes',
        #     'view_type': 'form',
        #     'view_mode': 'tree,form',
        #     'view_id': False,
        #     # 'view_id': self.id,
        #     'res_model': 'situation.decompte',
        #     'type': 'ir.actions.act_window',
        #     'target': 'current',
        #     'domain': domain,
        #     # 'domain': "[('id', 'in',%s)]" % (self.decompte_ids),
        #     # domain': "[self.id, ' in ', 'project_id']"
        # }
        # return tree_view


# class Partner(models.Model):
#     _inherit = "res.partner"
#
#     partner_rc = fields.Char(string='RC')
#     partner_nif = fields.Char(string='NIF')
#     partner_nis = fields.Char(string='NIS')
#     partner_ai = fields.Char(string='AI')
#     partner_rib = fields.Char(string='RIB')
#     partner_tin = fields.Char(string='TIN')
#
# class Company(models.Model):
#     _inherit = "res.company"
#
#     partner_rc = fields.Char(string='RC')
#     partner_nif = fields.Char(string='NIF')
#     partner_nis = fields.Char(string='NIS')
#     partner_ai = fields.Char(string='AI')
#     partner_rib = fields.Char(string='RIB')
#     partner_tin = fields.Char(string='TIN')
