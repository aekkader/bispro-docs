# -*- coding: utf-8 -*-
from odoo import api, fields, models

class SituationTaskMontant(models.Model):
    _name = "situation.task.montant"
    _description = "Situation Task Montant"

    # QUANTITE : contractuel precedente mois cumul
    qty_contractuel = fields.Float(string="Contractuel")
    qty_precedente = fields.Float(string="precedente")
    qty_mois = fields.Float(string="mois")
    qty_cumul = fields.Float(string="cumul")

    # MONTANTS : contractuel precedente mois total
    mnt_contractuel = fields.Float(string="Contractuel", compute='_mnt_contractuel')
    mnt_precedente = fields.Float(string="precedente", compute='_mnt_precedente')
    mnt_mois = fields.Float(string="mois", compute='_mnt_mois')
    mnt_total = fields.Float(string="total", compute='_mnt_total')

    task_id = fields.Many2one('situation.task', string="Tâches")
    decompte_id = fields.Many2one('situation.decompte', string="Décompte")
        # ondelete='cascade', string="Course", required=True)

    def name_get(self):
        result = []
        for task in self:
            name = task.task_id.sys_ctrl
            result.append((task.id, name))
        return result

    # # @api.depends('qty_contractuel', 'task_id.pu')
    # def _mnt_contractuel(self):
    #     self.mnt_contractuel = self.qty_contractuel * self.task_id.pu
    #     # if self.qty_contractuel:
    #     #     for r in self:
    #     #         r.mnt_contractuel = r.qty_contractuel * self.task_id.pu

    # @api.depends('qty_contractuel', 'pu')
    # @api.one
    def _mnt_contractuel(self):
        # self.mnt_contractuel = self.qty_contractuel * self.task_id.pu
        for r in self:
            r.mnt_contractuel = r.qty_contractuel * r.task_id.pu

    # @api.depends('qty_precedente', 'pu')
    def _mnt_precedente(self):
        # self.mnt_precedente = self.qty_precedente * self.task_id.pu
        for r in self:
            r.mnt_precedente = r.qty_precedente * r.task_id.pu

    # @api.depends('qty_mois', 'pu')
    def _mnt_mois(self):
        # self.mnt_mois = self.qty_mois * self.task_id.pu
        for r in self:
            r.mnt_mois = r.qty_mois * r.task_id.pu

    # @api.depends('qty_cumul', 'pu')
    def _mnt_total(self):
        # self.mnt_total = self.qty_cumul * self.task_id.pu
        for r in self:
            r.mnt_total = r.qty_cumul * r.task_id.pu


class SituationTask(models.Model):
    _name = "situation.task"
    _description = "Situation Task"

    sca = fields.Char(string='SCA')
    sys_ctrl = fields.Char(string="SYSTÈME DE CONTRÔLE D'AMBIANCE")

    # PU 
    pu = fields.Float(string="PU")

    qty = fields.Float(string="Qty")#qty_contractuel

    project_id = fields.Many2one('project.project', string='Projet')
    # client_id = fields.Many2one('res.partner', string='Client', domain="[('customer_rank', '=', True)]")
    # client_id = fields.Many2one('res.partner', string='Client')

    def name_get(self):
        result = []
        for task in self:
            name = task.sys_ctrl
            result.append((task.id, name))
        return result
