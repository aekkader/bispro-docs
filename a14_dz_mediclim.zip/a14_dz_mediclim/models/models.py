# from odoo import api, fields, models
from odoo import api, fields, models, _

class PurchaseOrder(models.Model):
    _inherit = "purchase.order"

    # state = fields.Selection(selection_add([('sent2Buy', 'sent to buy')]))
    # state = fields.Selection(selection_add_after={'sent': [('sent2Buy', 'Envoyer pour achat')]})
    # state = fields.Selection(
    #     selection_add=[
    #         ('sent2Buy', 'Envoyer pour achat')
    #     ],
    # )

    state = fields.Selection([
        ('draft', 'RFQ'),
        ('sent2Buy', 'Envoyer pour achat'),
        ('sent', 'RFQ Sent'),
        ('to approve', 'To Approve'),
        ('purchase', 'Purchase Order'),
        ('done', 'Locked'),
        ('cancel', 'Cancelled')
    ], string='Status', readonly=True, index=True, copy=False, default='draft', tracking=True)

     # @ api.multi
    def action_sent2Buy(self):
        # self.state = 'sent2Buy'
        self.write({'state': 'sent2Buy'})

    def button_confirm(self):
        for order in self:
            if order.state not in ['draft', 'sent', 'sent2Buy']:
                continue
            order._add_supplier_to_product()
            # Deal with double validation process
            if order._approval_allowed():
                order.button_approve()
            else:
                order.write({'state': 'to approve'})
            if order.partner_id not in order.message_partner_ids:
                order.message_subscribe([order.partner_id.id])
        return True

    def action_rfq_send(self):
        '''
        This function opens a window to compose an email, with the edi purchase template message loaded by default
        '''
        self.ensure_one()
        ir_model_data = self.env['ir.model.data']
        try:
            if self.env.context.get('send_rfq', False):
                template_id = ir_model_data.get_object_reference('purchase', 'email_template_edi_purchase')[1]
            else:
                template_id = ir_model_data.get_object_reference('purchase', 'email_template_edi_purchase_done')[1]
        except ValueError:
            template_id = False
        try:
            compose_form_id = ir_model_data.get_object_reference('mail', 'email_compose_message_wizard_form')[1]
        except ValueError:
            compose_form_id = False
        ctx = dict(self.env.context or {})
        ctx.update({
            'default_model': 'purchase.order',
            'active_model': 'purchase.order',
            'active_id': self.ids[0],
            'default_res_id': self.ids[0],
            'default_use_template': bool(template_id),
            'default_template_id': template_id,
            'default_composition_mode': 'comment',
            'custom_layout': "mail.mail_notification_paynow",
            'force_email': True,
            'mark_rfq_as_sent': True,
        })

        # In the case of a RFQ or a PO, we want the "View..." button in line with the state of the
        # object. Therefore, we pass the model description in the context, in the language in which
        # the template is rendered.
        lang = self.env.context.get('lang')
        if {'default_template_id', 'default_model', 'default_res_id'} <= ctx.keys():
            template = self.env['mail.template'].browse(ctx['default_template_id'])
            if template and template.lang:
                lang = template._render_lang([ctx['default_res_id']])[ctx['default_res_id']]

        self = self.with_context(lang=lang)
        if self.state in ['draft', 'sent', 'sent2Buy']:
            ctx['model_description'] = _('Request for Quotation')
        else:
            ctx['model_description'] = _('Purchase Order')

        print("H1")
        return {
            'name': _('Compose Email'),
            'type': 'ir.actions.act_window',
            'view_mode': 'form',
            'res_model': 'mail.compose.message',
            'views': [(compose_form_id, 'form')],
            'view_id': compose_form_id,
            'target': 'new',
            'context': ctx,
        }

    @api.returns('mail.message', lambda value: value.id)
    def message_post(self, **kwargs):
        if self.env.context.get('mark_rfq_as_sent'):
            self.filtered(lambda o: ((o.state == 'draft') | (o.state == 'sent2Buy'))).write({'state': 'sent'})
        return super(PurchaseOrder, self.with_context(mail_post_autofollow=True)).message_post(**kwargs)



# class Project(models.Model):
#     _inherit = "project.project"
#
#     is_state = fields.Boolean(string='Étatique', default=False)
#     # rating_active = fields.Boolean('Customer Ratings', default=True)
#     decompte_ids = fields.One2many('situation.decompte', 'project_id', string="Décomptes")
#
#     def total_project(self):
#         return 22
#
#     def show_decomptes(self):
#         tree_view = {
#             'name': 'Décomptes',
#             'view_type': 'form',
#             'view_mode': 'tree,form',
#             'view_id': False,
#             # 'view_id': self.id,
#             'res_model': 'situation.decompte',
#             'type': 'ir.actions.act_window',
#             'target': 'current',
#         }
#         return tree_view

    # # @api.multi
    # def show_decomptes(self):
        # print self._context
        # course_form = self.env.ref('college.return_form', False)
        # return {
        #     'name': 'New Course',
        #     'type': 'ir.actions.act_window',
        #     'res_model': 'situation.decompte',
        #     'view_type': 'form',
        #     'view_mode': 'tree,form',
        #     'target': 'self',
        #     'views': [(self.decompte_ids, 'tree')],
        #     # 'view_id': 'course_form.id',
        #     'flags': {'action_buttons': True},
        #     }

        # context = self._context.copy()
        # return {
        #     'name': 'form_name',
        #     'view_type': 'form',
        #     'view_mode': 'tree',
        #     'views': [(self.decompte_ids, 'form')],
        #     'res_model': 'model_name',
        #     'view_id': self.decompte_ids,
        #     'type': 'ir.actions.act_window',
        #     'res_id': self.id,
        #     'target': 'new',
        #     'context': context,
        # }
        # domain = [('id', 'in', self.decompte_ids)]
        # domain = [(self.id, '=', 'project_id')]
        # tree_view = {
        #     'name': 'Décomptes',
        #     'view_type': 'form',
        #     'view_mode': 'tree,form',
        #     'view_id': False,
        #     # 'view_id': self.id,
        #     'res_model': 'situation.decompte',
        #     'type': 'ir.actions.act_window',
        #     'target': 'current',
        #     'domain': domain,
        #     # 'domain': "[('id', 'in',%s)]" % (self.decompte_ids),
        #     # domain': "[self.id, ' in ', 'project_id']"
        # }
        # return tree_view

# class Partner(models.Model):
#     _inherit = "res.partner"
#
#     partner_rc = fields.Char(string='RC')
#     partner_nif = fields.Char(string='NIF')
#     partner_nis = fields.Char(string='NIS')
#     partner_ai = fields.Char(string='AI')
#     partner_rib = fields.Char(string='RIB')
#     partner_tin = fields.Char(string='TIN')
#
# class Company(models.Model):
#     _inherit = "res.company"
#
#     partner_rc = fields.Char(string='RC')
#     partner_nif = fields.Char(string='NIF')
#     partner_nis = fields.Char(string='NIS')
#     partner_ai = fields.Char(string='AI')
#     partner_rib = fields.Char(string='RIB')
#     partner_tin = fields.Char(string='TIN')
