from odoo import api, fields, models, _

# from odoo import api, fields, models, SUPERUSER_ID, _
from odoo.tools.misc import formatLang, get_lang
import json


class SaleOrder(models.Model):
    _inherit = "sale.order"


    # def refresh_orde_lines(self):
    #     for r in self:
    #         print(r)

    def refresh_orde_lines(self):
        pages = []
        for line in self.order_line:
            # print("Pere")
            # print(line.product_id.name)
            # y = json.dumps(x)
            # pages.append((0, 0, json.dumps(line)))
            vals = {
                'product_id': line.product_id.id,
                'order_id': self.id,
                'name': line.name,
                'product_uom_qty': line.product_uom_qty or 1,
                'price_unit': line.price_unit,
                'price_subtotal': line.price_subtotal,
                'tax_id': line.tax_id,
                # vals['product_uom'] = find_product.uom_id.id
            }
            pages.append((0, 0, vals))

            for line_ord in line.product_id.product_line_ids:
                find_product = self.env['product.product'].search([('product_tmpl_id', '=', line_ord.product_id3.id)])
                # print("Fils")
                # print(find_product.name)
                vals = {
                    'product_id': find_product.id,
                    'order_id': self.id,
                    'name': find_product.name,
                    'product_uom_qty': line_ord.qty or 1,
                    'price_unit': line_ord.prix,
                    'price_subtotal': line_ord.total,
                    # 'price_unit': 0,
                    # 'price_subtotal': 0,
                    'tax_id': self.env['account.tax'].search([('id', '=', find_product.taxes_id.id)]),
                    # vals['product_uom'] = find_product.uom_id.id
                }
                # vals['tax_id'] = self.env['account.tax'].search([('id', '=', find_product.taxes_id.id)])
                pages.append((0, 0, vals))

        self.order_line = [(5, 0, 0)]#Clear all
        self.order_line = pages


class PurchaseOrder(models.Model):
    _inherit = "purchase.order"

    # state = fields.Selection(selection_add([('sent2Buy', 'sent to buy')]))
    # state = fields.Selection(selection_add_after={'sent': [('sent2Buy', 'Envoyer pour achat')]})
    # state = fields.Selection(
    #     selection_add=[
    #         ('sent2Buy', 'Envoyer pour achat')
    #     ],
    # )

    state = fields.Selection([
        ('draft', 'RFQ'),
        ('sent2Buy', 'Envoyer pour achat'),
        ('sent', 'RFQ Sent'),
        ('to approve', 'To Approve'),
        ('purchase', 'Purchase Order'),
        ('done', 'Locked'),
        ('cancel', 'Cancelled')
    ], string='Status', readonly=True, index=True, copy=False, default='draft', tracking=True)

     # @ api.multi
    def action_sent2Buy(self):
        # self.state = 'sent2Buy'
        self.write({'state': 'sent2Buy'})

    def button_confirm(self):
        for order in self:
            if order.state not in ['draft', 'sent', 'sent2Buy']:
                continue
            order._add_supplier_to_product()
            # Deal with double validation process
            if order._approval_allowed():
                order.button_approve()
            else:
                order.write({'state': 'to approve'})
            if order.partner_id not in order.message_partner_ids:
                order.message_subscribe([order.partner_id.id])
        return True

    def action_rfq_send(self):
        '''
        This function opens a window to compose an email, with the edi purchase template message loaded by default
        '''
        self.ensure_one()
        ir_model_data = self.env['ir.model.data']
        try:
            if self.env.context.get('send_rfq', False):
                template_id = ir_model_data.get_object_reference('purchase', 'email_template_edi_purchase')[1]
            else:
                template_id = ir_model_data.get_object_reference('purchase', 'email_template_edi_purchase_done')[1]
        except ValueError:
            template_id = False
        try:
            compose_form_id = ir_model_data.get_object_reference('mail', 'email_compose_message_wizard_form')[1]
        except ValueError:
            compose_form_id = False
        ctx = dict(self.env.context or {})
        ctx.update({
            'default_model': 'purchase.order',
            'active_model': 'purchase.order',
            'active_id': self.ids[0],
            'default_res_id': self.ids[0],
            'default_use_template': bool(template_id),
            'default_template_id': template_id,
            'default_composition_mode': 'comment',
            'custom_layout': "mail.mail_notification_paynow",
            'force_email': True,
            'mark_rfq_as_sent': True,
        })

        # In the case of a RFQ or a PO, we want the "View..." button in line with the state of the
        # object. Therefore, we pass the model description in the context, in the language in which
        # the template is rendered.
        lang = self.env.context.get('lang')
        if {'default_template_id', 'default_model', 'default_res_id'} <= ctx.keys():
            template = self.env['mail.template'].browse(ctx['default_template_id'])
            if template and template.lang:
                lang = template._render_lang([ctx['default_res_id']])[ctx['default_res_id']]

        self = self.with_context(lang=lang)
        if self.state in ['draft', 'sent', 'sent2Buy']:
            ctx['model_description'] = _('Request for Quotation')
        else:
            ctx['model_description'] = _('Purchase Order')

        print("H1")
        return {
            'name': _('Compose Email'),
            'type': 'ir.actions.act_window',
            'view_mode': 'form',
            'res_model': 'mail.compose.message',
            'views': [(compose_form_id, 'form')],
            'view_id': compose_form_id,
            'target': 'new',
            'context': ctx,
        }

    @api.returns('mail.message', lambda value: value.id)
    def message_post(self, **kwargs):
        if self.env.context.get('mark_rfq_as_sent'):
            self.filtered(lambda o: ((o.state == 'draft') | (o.state == 'sent2Buy'))).write({'state': 'sent'})
        return super(PurchaseOrder, self.with_context(mail_post_autofollow=True)).message_post(**kwargs)
