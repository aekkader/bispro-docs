from odoo import api, fields, models


class CustomInvoiceLine(models.Model):
    _name = "custom.invoice.line"

    qty = fields.Integer(string="Qty")

    custom_invoice_id_v2 = fields.Many2one('custom.invoice', 'Custom Invoice v2')

    custom_invoice_id = fields.Many2one('custom.invoice', 'Custom Invoice')


class CustomInvoice(models.Model):
    _name = "custom.invoice"

    numero = fields.Integer(string="Numéro")
    name = fields.Char(string="Nom")

    custom_invoice_line_ids = fields.One2many('custom.invoice.line', 'custom_invoice_id', string="Custom Invoice Line"
                                              , copy=True, auto_join=True)
    # custom_invoice_line_ids = fields.Many2one('custom.invoice.line', string="Custom Invoice Line")

    # def name_get(self):
    #     result = []
    #     for prod in self:
    #         name = prod.name
    #         result.append((prod.id, name))
    #     return result


    def action_custom_print(self):
        # return "mm"
        # return self.env.ref('test.test_report').report_action(record_id)
        # return self.env.ref('module_name.XML_ID_of_report').report_action(self)
        return self.env.ref('a14_dz_mediclim.report_custom_invoice').report_action(self)


class CustomInvoiceAccountMove(models.Model):
    _inherit = "account.move"

    def action_custom_print(self):
        # return "mm"
        # return self.env.ref('test.test_report').report_action(record_id)
        # return self.env.ref('module_name.XML_ID_of_report').report_action(self)
        return self.env.ref('a14_dz_mediclim.a14_report_custom_invoice_service').report_action(self)
