# -*- coding: utf-8 -*-
{
    'name': "Mediclim",

    'summary': """
        DZ Mediclim : odoo14""",

    'description': """
        DZ Mediclim : odoo14""",

    'author': "My Company",
    'website': "http://www.yourcompany.com",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/14.0/odoo/addons/base/data/ir_module_category_data.xml
    # for the full list
    'category': 'Uncategorized',
    'version': '0.1',

    # any module necessary for this one to work correctly
    'depends': ['base', 'project', 'purchase', 'sale'],

    # always loaded
    'data': [
        'security/security.xml',
        'security/ir.model.access.csv',
        # 'views/mediclim.xml',
        'views/serviceprice.xml',
        'views/sale.xml',
        'views/purchase.xml',
        # 'views/mediclim_dashboard.xml',
        # 'views/invoice.xml',
        # 'reports/invoice.xml',
        # 'reports/reports.xml',
        # 'reports/reports_sale.xml',
    ],
    # only loaded in demonstration mode
    'demo': [
        'demo/demo.xml',
    ],
    'application': True,
}
