# -*- coding: utf-8 -*-
from odoo import api, fields, models, exceptions

class SituationAvancement(models.Model):
    _name = "situation.avancement"
    _description = "Situation Avancement"

    qty_avancement = fields.Float(string="Qty avancemnt")
    project_id = fields.Many2one('project.project', string='Projet', domain=[('is_state','=',True)])
    decompte_id = fields.Many2one('situation.decompte', string='Décompte')
    task_mnt_id = fields.Many2one('situation.task.montant', string="Tâche")

    def name_get(self):
        result = []
        for avancement in self:
            name = "Mettre à jour "+str(avancement.qty_avancement)
            result.append((avancement.id, name))
        return result

    @api.onchange('project_id')
    def onchange_project_id(self):
        for rec in self:
            return {'domain': {'decompte_id': [('project_id', '=', rec.project_id.id)]}}

    @api.onchange('decompte_id')
    def onchange_decompte_id(self):
        for rec in self:
            return {'domain': {'task_mnt_id': [('decompte_id', '=', rec.decompte_id.id), ('is_progress','=',False)]}}

    # # """
    # #     Update task : field mois
    # # """
    # # @api.model_create_multi
    # # @api.model
    # def create(self, vals_list):
    #     # avancemnt = super(SituationAvancement).create(vals_list)
    #     # avancemnt = super(SituationAvancement, self.with_context(create_situation_avancemnt=True)).create(vals_list)
    #     avancemnt = super(SituationAvancement, self).create(vals_list)
    #     # self.update_task(avancemnt)
    #     # self._update_task()

    def update_task(self):
        decompte_ids = self.project_id.decompte_ids
        sumqty=0
        for decompte in decompte_ids:
            for task_mnt in decompte.task_mnt_ids:
                if self.task_mnt_id.task_id == task_mnt.task_id:
                    sumqty += task_mnt.qty_mois

        for r in self:
            if r.qty_avancement > (r.task_mnt_id.qty_contractuel - sumqty):
                raise exceptions.ValidationError("Qté non valide")
            else:
                # r.task_mnt_id.update({'qty_mois': r.qty_avancement})
                r.task_mnt_id.update({'qty_mois': r.qty_avancement, 'is_progress': True})

    # # @api.onchange('qty_avancement')
    # @api.constrains('qty_avancement')
    # def _verify_qty_avancement(self):
    #     for r in self:
    #         if r.qty_avancement > r.task_mnt_id.qty_contractuel:
    #             raise exceptions.ValidationError("A session's instructor can't be an attendee")
    #
    #     # if self.qty_avancement > self.task_mnt_id.qty_contractuel:
    #         # return {
    #         #     'warning': {
    #         #         'title': "Incorrect 'seats' value",
    #         #         'message': "The number of available seats may not be negative",
    #         #     },
    #         # }

