# -*- coding: utf-8 -*-
from odoo import api, fields, models
from datetime import datetime


class SituationDecompte(models.Model):
    _name = "situation.decompte"
    # _inherit = ["mail.thread"]
    _inherit = ['portal.mixin', 'mail.thread', 'mail.activity.mixin', 'utm.mixin']
    _description = "Situation Décompte"

    numero = fields.Integer(string='Numéro')
    # numero = fields.Integer(string='Numéro', help="Numéro de décompte", readonly="1", copy=False, index=True)
    # numero = fields.Integer(string='Numéro', help="Numéro de décompte", readonly="1")

    start_date = fields.Date(default=fields.Date.today, string='Date de début')
    end_date = fields.Date(default=fields.Date.today, string='Date de fin')

    description = fields.Char(string='Description')

    # project_id = fields.Many2one('project.project', string='Projet')
    project_id = fields.Many2one('project.project', string='Projet', domain=[('is_state','=',True)])

    task_mnt_ids = fields.One2many('situation.task.montant', 'decompte_id', string="Tâches")

    engineer_id = fields.Many2one('res.users', string='Ingénieur', domain=[('is_engineer','=',True)])
    # engineer_id = fields.Many2one('res.users', string='Ingénieur')
    # Filter user: is engineer

    is_valid = fields.Boolean(string='Valide', default=False)

    # payment_term_id = fields.Many2one(
    #     'account.payment.term', string='Conditions de paiement', check_company=True,  # Unrequired company
    #     domain="['|', ('company_id', '=', False), ('company_id', '=', company_id)]",)
    # < field
    # name = "payment_term_id"
    # options = "{'no_open':True,'no_create': True}" / >

    state = fields.Selection([
        ('draft', 'Décompte'),
        ('sent to engineer', 'Affecté à l’ingénieur'),
        ('sent to client', 'Affecté au client'),
        # ('sent', 'RFQ Sent'),
        # ('to approve', 'To Approve'),
        ('decompte', 'Facturé'),
        # ('done', 'Locked'),
        # ('cancel', 'Annuler')
    ], string='Status', readonly=True, index=True, copy=False, default='draft', tracking=True)

    # @api.model
    # def create(self, vals):
    #     vals['numero'] = self.env['ir.sequence'].next_by_code('situation.decompte')
    #     return super(SituationDecompte, self).create(vals)

    # def filter(self):
    #     context = self._context
    #     current_uid = context.get('uid')
    #     user = self.env['res.users'].browse(current_uid)
    #     return user.is_engineer
    #
    # def _getFilterDomain(self):
    #     # return [(self.filter(), '=', True)]
    #     context = self._context
    #     current_uid = context.get('uid')
    #     # return [('engineer_id', '=', current_uid)]
    #     return {'domain':{'engineer_id':[('engineer_id','=',current_uid)]}}


    def action_sent2Engineer(self):
        # self.state = 'sent2Buy'
        self.write({'state': 'sent to engineer'})

    def action_sent2Client(self):
        # self.state = 'sent2Buy'
        self.write({'state': 'sent to client'})

    def action_validate(self):
        # self.state = 'sent2Buy'
        self.write({'state': 'decompte'})
        self.update({'is_valid': True})

    def action_invalidate(self):
        # self.state = 'sent2Buy'
        self.write({'state': 'draft'})
        self.update({'is_valid': False})

    def action_create_invoice(self):
        # self.state = 'sent2Buy'
        self.write({'state': 'decompte'})
        self._create_invoices()

    def action_sent2Buy(self):
        # self.state = 'sent2Buy'
        self.write({'state': 'sent2Buy'})

    def name_get(self):
        result = []
        for decompte in self:
            name = "Décompte des travaux réalisé N° "+str(decompte.numero)
            result.append((decompte.id, name))
        return result

    def print_custom_decompte(self):
        # return "mm"
        # return self.env.ref('test.test_report').report_action(record_id)
        # return self.env.ref('module_name.XML_ID_of_report').report_action(self)
        return self.env.ref('a14_dz_mediclim_v4.report_decompte').report_action(self)


    # def generate_decompte_num(self):
    #     new_num = 0
    #     decompte = self.env['situation.decompte'].search([('project_id', '=', self.project_id.id)], limit=1, order='create_date desc')
    #     if decompte:
    #         new_num = decompte.numero
    #     new_num += 1
    #
    #     for rec in self:
    #         rec.numero = new_num
    #
    #     print(new_num)
    #     print(self.numero)

    @api.onchange('project_id')
    def onchange_project_id(self):
        task_mnt_ids = []
        if self.project_id:
            task_ids = self.env['situation.task'].search([('project_id', '=', self.project_id.id)])
            for task_id in task_ids:
                task_mnt_ids.append((0, 0, {'task_id': task_id.id
                    , 'qty_contractuel': task_id.qty, 'qty_precedente': 0
                    , 'qty_mois': 0, 'qty_cumul': 0
                                            , 'pu': task_id.pu
                    , 'mnt_contractuel': 0, 'mnt_precedente': 0
                    , 'mnt_mois': 0, 'mnt_total': 0
                                            }))

        self.task_mnt_ids = [(5, 0, 0)]#Clear all
        self.task_mnt_ids = task_mnt_ids
        # self.generate_decompte_num()

    #
    # Generate Invoice
    #
    def _prepare_invoice(self):
        invoice_vals = {
            'move_type': 'out_invoice',
            'name': 'Décompte N° '+str(self.numero),
            'payment_reference': 'Décompte N° '+str(self.numero),
            'partner_id': self.project_id.partner_id,
            'invoice_date': datetime.today(),
            # 'invoice_payment_term_id': self.payment_term_id.id,
            'narration': self.description,
            'invoice_line_ids': [],

            # 'ref': self.project_id.partner_id or '',
            # 'currency_id': self.pricelist_id.currency_id.id,
            # 'campaign_id': self.campaign_id.id,
            # 'medium_id': self.medium_id.id,
            # 'source_id': self.source_id.id,
            # 'invoice_user_id': self.user_id and self.user_id.id,
            # 'team_id': self.team_id.id,
            # 'partner_shipping_id': self.partner_shipping_id.id,
            # 'fiscal_position_id': (self.fiscal_position_id or self.fiscal_position_id.get_fiscal_position(self.partner_invoice_id.id)).id,
            # 'partner_bank_id': self.company_id.partner_id.bank_ids[:1].id,
            # 'journal_id': journal.id,  # company comes from the journal
            # 'invoice_origin': self.name,
            # 'transaction_ids': [(6, 0, self.transaction_ids.ids)],
            # 'company_id': self.company_id.id,
        }
        return invoice_vals

    def _prepare_invoice_line(self, task_line):
        product = task_line._create_product_service()

        # 'product_id': order_line.product_id.id,
        # 'quantity': order_line.qty if self.amount_total >= 0 else -order_line.qty,
        # 'discount': order_line.discount,
        # 'price_unit': order_line.price_unit,
        # 'name': order_line.product_id.display_name,
        # 'tax_ids': [(6, 0, order_line.tax_ids_after_fiscal_position.ids)],
        # 'product_uom_id': order_line.product_uom_id.id,

        task_invoice_line = {
            'product_id': product,
            'quantity': task_line.qty_mois,
            # 'discount': order_line.discount,
            'price_unit': task_line.pu,
            'name': product.name,
            # 'tax_ids': [(6, 0, order_line.tax_ids_after_fiscal_position.ids)],
            # 'tax_ids': [(6, 0, task_line.tax_id.ids)],
            # 'product_uom_id': order_line.product_uom_id.id,
        }
        return task_invoice_line

    # def _create_invoices(self, grouped=False, final=False, date=None):
    def _create_invoices(self):
        # 1) Create invoices.
        invoice_vals_list = []
        invoice_vals = self._prepare_invoice()
        # invoiceable_lines = order._get_invoiceable_lines(final)

        invoice_vals_list.append(invoice_vals)

        # invoices lines
        invoice_line_vals = []
        # invoice_line_vals.append(
        #     (0, 0, order._prepare_down_payment_section_line(
        #         sequence=invoice_item_sequence,
        #     )),
        # )
        for task_line in self.task_mnt_ids:
            # invoice_line_vals.append((0, 0, {'task_id': task_id.id
            #     , 'qty_contractuel': task_id.qty, 'qty_precedente': 0
            #     , 'qty_mois': 0, 'qty_cumul': 0
            #     , 'pu': task_id.pu
            #     , 'mnt_contractuel': 0, 'mnt_precedente': 0
            #     , 'mnt_mois': 0, 'mnt_total': 0
            #     }))
            invoice_line_vals.append(
                    (0, 0, self._prepare_invoice_line(task_line)),
                )

        invoice_vals['invoice_line_ids'] += invoice_line_vals
        invoice_vals_list.append(invoice_vals)

        # if not invoice_vals_list:
        #     raise self._nothing_to_invoice_error()

        # Manage the creation of invoices in sudo because a salesperson must be able to generate an invoice from a
        # sale order without "billing" access rights. However, he should not be able to create an invoice from scratch.
        moves = self.env['account.move'].sudo().with_context(default_move_type='out_invoice').create(invoice_vals_list)

        return moves
