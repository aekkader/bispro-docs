# -*- coding: utf-8 -*-
from odoo import api, fields, models
from datetime import datetime


class SituationDecompte(models.Model):
    _name = "situation.decompte"
    # _inherit = ["mail.thread"]
    _inherit = ['portal.mixin', 'mail.thread', 'mail.activity.mixin', 'utm.mixin']
    _description = "Situation Décompte"

    numero = fields.Integer(string='Numéro')
    # numero = fields.Integer(string='Numéro', help="Numéro de décompte", readonly="1", copy=False, index=True)
    # numero = fields.Integer(string='Numéro', help="Numéro de décompte", readonly="1")

    start_date = fields.Date(default=fields.Date.today, string='Date de début')
    end_date = fields.Date(default=fields.Date.today, string='Date de fin')

    description = fields.Char(string='Description')

    # project_id = fields.Many2one('project.project', string='Projet')
    project_id = fields.Many2one('project.project', string='Projet', domain=[('is_state','=',True)])

    task_mnt_ids = fields.One2many('situation.task.montant', 'decompte_id', string="Tâches")

    engineer_id = fields.Many2one('res.users', string='Ingénieur', domain=[('is_engineer','=',True)])
    # engineer_id = fields.Many2one('res.users', string='Ingénieur')
    # Filter user: is engineer

    is_valid = fields.Boolean(string='Valide', default=False)

    # payment_term_id = fields.Many2one(
    #     'account.payment.term', string='Conditions de paiement', check_company=True,  # Unrequired company
    #     domain="['|', ('company_id', '=', False), ('company_id', '=', company_id)]",)
    # < field
    # name = "payment_term_id"
    # options = "{'no_open':True,'no_create': True}" / >

    state = fields.Selection([
        ('draft', 'Décompte'),
        ('sent to engineer', 'Affecté à l’ingénieur'),
        ('sent to client', 'Affecté au client'),
        # ('sent', 'RFQ Sent'),
        # ('to approve', 'To Approve'),
        ('decompte', 'Facturé'),
        # ('done', 'Locked'),
        # ('cancel', 'Annuler')
    ], string='Status', readonly=True, index=True, copy=False, default='draft', tracking=True)

    # @api.model
    # def create(self, vals):
    #     vals['numero'] = self.env['ir.sequence'].next_by_code('situation.decompte')
    #     return super(SituationDecompte, self).create(vals)

    # def filter(self):
    #     context = self._context
    #     current_uid = context.get('uid')
    #     user = self.env['res.users'].browse(current_uid)
    #     return user.is_engineer
    #
    # def _getFilterDomain(self):
    #     # return [(self.filter(), '=', True)]
    #     context = self._context
    #     current_uid = context.get('uid')
    #     # return [('engineer_id', '=', current_uid)]
    #     return {'domain':{'engineer_id':[('engineer_id','=',current_uid)]}}


    def action_sent2Engineer(self):
        # self.state = 'sent2Buy'
        self.write({'state': 'sent to engineer'})

    def action_sent2Client(self):
        # self.state = 'sent2Buy'
        self.write({'state': 'sent to client'})

    def action_validate(self):
        # self.state = 'sent2Buy'
        self.write({'state': 'decompte'})
        self.update({'is_valid': True})

    def action_invalidate(self):
        # self.state = 'sent2Buy'
        self.write({'state': 'draft'})
        self.update({'is_valid': False})

    def action_create_invoice(self):
        # self.state = 'sent2Buy'
        self.write({'state': 'decompte'})
        # for rec in self:
        self._create_invoices()

    def action_sent2Buy(self):
        # self.state = 'sent2Buy'
        self.write({'state': 'sent2Buy'})

    def name_get(self):
        result = []
        for decompte in self:
            name = "Décompte des travaux réalisé N° "+str(decompte.numero)
            result.append((decompte.id, name))
        return result

    def print_custom_decompte(self):
        # return "mm"
        # return self.env.ref('test.test_report').report_action(record_id)
        # return self.env.ref('module_name.XML_ID_of_report').report_action(self)
        return self.env.ref('a14_dz_mediclim_v4.report_decompte').report_action(self)

    @api.onchange('project_id')
    def onchange_project_id(self):
        task_mnt_ids = []
        if self.project_id:
            task_ids = self.env['situation.task'].search([('project_id', '=', self.project_id.id)])
            for task_id in task_ids:
                task_mnt_ids.append((0, 0, {'task_id': task_id.id
                    , 'qty_contractuel': task_id.qty, 'qty_precedente': 0
                    , 'qty_mois': 0, 'qty_cumul': 0
                                            , 'pu': task_id.pu
                    , 'mnt_contractuel': 0, 'mnt_precedente': 0
                    , 'mnt_mois': 0, 'mnt_total': 0
                                            }))

        self.task_mnt_ids = [(5, 0, 0)]#Clear all
        self.task_mnt_ids = task_mnt_ids
        # self.generate_decompte_num()


####################################################################################################
    ##
    ##   Prepare/Create invoice
    ##
####################################################################################################

    #
    # Prepare invoice line
    #
    def _prepare_invoice(self):
        invoice_vals = {
            'move_type': 'out_invoice',
            'name': 'Décompte N° '+str(self.numero),
            'payment_reference': 'Décompte N° '+str(self.numero),
            'partner_id': self.project_id.partner_id,
            'invoice_date': datetime.today(),
            # 'invoice_payment_term_id': self.payment_term_id.id,
            'narration': self.description,
            'invoice_line_ids': [],
        }
        return invoice_vals

    #
    # Prepare invoice line
    #
    def _prepare_invoice_line(self, task_line):
        return {
            # 'product_id': task_line.id,
            'price_unit': task_line.pu,
            'name': task_line.task_id.sys_ctrl,
            'quantity': task_line.qty_mois,
        }

    # #
    # # Generate Invoice
    # #
    def _create_invoices(self):
        # 1) Create invoices.
        invoice_vals_list = []

        for rec in self:
            invoice_vals = rec._prepare_invoice()

            invoice_line_vals = []
            for task_line in rec.task_mnt_ids:
                invoice_line_vals.append((0, 0, rec._prepare_invoice_line(task_line)),)

            invoice_vals['invoice_line_ids'] = invoice_line_vals
            invoice_vals_list.append(invoice_vals)

        moves = self.env['account.move'].create(invoice_vals_list)

        return moves
