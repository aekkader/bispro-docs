# -*- coding: utf-8 -*-
from odoo import api, fields, models

class SituationTaskMontant(models.Model):
    _name = "situation.task.montant"
    _description = "Situation Task Montant"

    # QUANTITE : contractuel precedente mois cumul
    qty_contractuel = fields.Float(string="Contractuel")
    qty_precedente = fields.Float(string="precedente", compute='_qty_precedente')
    qty_mois = fields.Float(string="mois")
    # qty_cumul = fields.Float(string="cumul")
    qty_cumul = fields.Float(string="cumul", compute='_qty_cumul')

    # PU
    pu = fields.Float(string="PU")

    # MONTANTS : contractuel precedente mois total
    mnt_contractuel = fields.Float(string="Contractuel", compute='_mnt_contractuel')
    mnt_precedente = fields.Float(string="precedente", compute='_mnt_precedente')
    mnt_mois = fields.Float(string="mois", compute='_mnt_mois')
    mnt_total = fields.Float(string="total", compute='_mnt_total')

    task_id = fields.Many2one('situation.task', string="Tâches")
    decompte_id = fields.Many2one('situation.decompte', string="Décompte")
        # ondelete='cascade', string="Course", required=True)

    is_progress = fields.Boolean(string='Progress', default=False)
    # tax_id = fields.Many2many('account.tax', string='Taxes', domain=['|', ('active', '=', False), ('active', '=', True)])

    # @api.model
    # def get_taxes(self):
    #     return self.env['my.tax.tax'].search([('type', 'in', ['income', 'value', 'excise'])]).ids
    #
    # tax_id = fields.Many2many('account.tax', string='Taxes', domain=['|', ('active', '=', False), ('active', '=', True)])


    # #
    # # Create Product from task Line
    # #
    # # @api.model_create_multi
    # def _create_product_service(self):
    #     # default_code = "Décompte N° "+str(self.decompte_id.numero)
    #     for rec in self:
    #         vals_prod_tmp = {
    #             'name': rec.task_id.sys_ctrl,
    #             'description': rec.task_id.sys_ctrl,
    #             'type': 'service',
    #             'list_price': rec.pu,
    #             # 'default_code': default_code,
    #         }
    #         print("Avant : product_tmp")
    #         product_tmp = rec.env['product.template'].create(vals_prod_tmp)
    #         product_tmp._create_variant_ids()
    #         print("product_tmp")
    #         print(product_tmp)
    #
    #         vals_prod = {
    #             # 'default_code': default_code,
    #             'product_tmpl_id': product_tmp.id,
    #         }
    #         product = rec.env['product.product'].create(vals_prod)
    #
    #         # if "create_product_product" not in self._context:
    #         # product._create_variant_ids()
    #         # products.write(vals_list)
    #         rec.clear_caches()
    #
    #     return product

    # def _create_product_service(self):
    #     default_code = "service"+str(self.qty_contractuel)
    #     vals_list = {
    #         'name': self.task_id.sys_ctrl,
    #         'description': self.task_id.sys_ctrl,
    #         'type': 'service',
    #         'list_price': self.pu,
    #         'default_code': default_code,
    #     }
    #
    #     products = self.env['product.template'].create(vals_list)
    #     if "create_product_product" not in self._context:
    #         products._create_variant_ids()
    #
    #     return products

    def name_get(self):
        result = []
        for task in self:
            name = task.task_id.sys_ctrl
            result.append((task.id, name))
        return result

    # @api.onchange('task_id')
    # def onchange_task_id(self):
    #     for r in self:
    #         r.pu = self.task_id.pu

    # # @api.depends('qty_contractuel', 'task_id.pu')
    # def _mnt_contractuel(self):
    #     self.mnt_contractuel = self.qty_contractuel * self.task_id.pu
    #     # if self.qty_contractuel:
    #     #     for r in self:
    #     #         r.mnt_contractuel = r.qty_contractuel * self.task_id.pu


    def _qty_cumul(self):
        for r in self:
            r.qty_cumul = r.qty_precedente + r.qty_mois


    def _qty_precedente(self):
        for r in self:
            # decompte_ids = r.decompte_id.project_id.decompte_ids
            decompte_ids = self.old_decomptes()
            print(decompte_ids)
            sumqty=0
            for decompte in decompte_ids:
                # if r.decompte_id == decompte:
                for task_mnt in decompte.task_mnt_ids:
                    if r.task_id == task_mnt.task_id:
                        sumqty += task_mnt.qty_mois

            r.qty_precedente = sumqty
        # print("sumqty")

        # for r in self:
        #     r.qty_precedente = sumqty

    def old_decomptes(self):
        old_decomptes=[]
        # for r in self:
        decompte_ids = self.decompte_id.project_id.decompte_ids
        for decompte in decompte_ids:
            if decompte.numero < self.decompte_id.numero:
                old_decomptes.append(decompte)

        return old_decomptes

    # def old_decompte(self):
    #     for r in self:
    #         decompte_ids = r.decompte_id.project_id.decompte_ids
    #         for decompte in decompte_ids:
    #             if decompte.numero == r.decompte_id.numero-1:
    #                 return decompte
    #
    # def _qty_precedente_v4(self):
    #     for r in self:
    #         sumqty = 0
    #         old_decompte = self.old_decompte()
    #         if old_decompte:
    #             for task_mnt in old_decompte.task_mnt_ids:
    #                 if r.task_id == task_mnt.task_id:
    #                     sumqty += task_mnt.qty_mois
    #         r.qty_precedente = sumqty


    # @api.depends('qty_contractuel', 'pu')
    # @api.one
    def _mnt_contractuel(self):
        # self.mnt_contractuel = self.qty_contractuel * self.task_id.pu
        for r in self:
            r.mnt_contractuel = r.qty_contractuel * r.task_id.pu

    # @api.depends('qty_precedente', 'pu')
    def _mnt_precedente(self):
        # self.mnt_precedente = self.qty_precedente * self.task_id.pu
        for r in self:
            r.mnt_precedente = r.qty_precedente * r.task_id.pu

    # @api.depends('qty_mois', 'pu')
    def _mnt_mois(self):
        # self.mnt_mois = self.qty_mois * self.task_id.pu
        for r in self:
            r.mnt_mois = r.qty_mois * r.task_id.pu

    # @api.depends('qty_cumul', 'pu')
    def _mnt_total(self):
        # self.mnt_total = self.qty_cumul * self.task_id.pu
        for r in self:
            r.mnt_total = r.qty_cumul * r.task_id.pu


class SituationTask(models.Model):
    _name = "situation.task"
    _description = "Situation Task"

    sca = fields.Char(string='SCA')
    sys_ctrl = fields.Char(string="SYSTÈME DE CONTRÔLE D'AMBIANCE")

    # PU 
    pu = fields.Float(string="PU")

    qty = fields.Float(string="Qty")#qty_contractuel

    # project_id = fields.Many2one('project.project', string='Projet')
    project_id = fields.Many2one('project.project', string='Projet', domain=[('is_state','=',True)])
    # client_id = fields.Many2one('res.partner', string='Client', domain="[('customer_rank', '=', True)]")
    # client_id = fields.Many2one('res.partner', string='Client')

    def name_get(self):
        result = []
        for task in self:
            name = task.sys_ctrl
            result.append((task.id, name))
        return result


    product_id = fields.Many2one('product.product', string='Product')


    @api.model_create_multi
    def create(self, vals_list):
        # tasks = super(SituationTask).create(vals_list)
        # tasks = super(SituationTask, self.with_context(create_situation_task=True)).create(vals_list)
        tasks = super(SituationTask, self).create(vals_list)
        # `_get_variant_id_for_combination` depends on existing variants
        # self.clear_caches()

        product = self._create_product_service(tasks)
        tasks.update({'product_id': product})

        return tasks

    #
    # Create Product from task
    #
    # @api.model_create_multi
    def _create_product_service(self, task):
        # print("_create_product_service")
        vals_prod_tmp = {
            'name': task.sys_ctrl,
            'description': task.sys_ctrl,
            'type': 'service',
            'list_price': task.pu,
            # 'default_code': default_code,
        }

        product_tmp = self.env['product.template'].create(vals_prod_tmp)
        product = self.env['product.product'].search([('product_tmpl_id', '=', product_tmp.id)])

        return product
